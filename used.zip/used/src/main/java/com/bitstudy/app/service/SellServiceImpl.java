package com.bitstudy.app.service;

import com.bitstudy.app.domain.ProductDto;

public interface SellServiceImpl {
    int proInsert(ProductDto DTO);
}
